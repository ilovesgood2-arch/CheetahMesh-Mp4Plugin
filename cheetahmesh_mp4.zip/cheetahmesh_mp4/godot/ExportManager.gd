extends Node

# =============================================
# ExportManager.gd — CheetahMesh
# =============================================

var scene_manager:  Node
var object_manager: Node
var camera_manager: Node
var anim_manager:   Node
var scene_objects:  Node3D

const EXPORT_DIR_ANDROID := "/storage/emulated/0/Download/CheetahMesh"
const EXPORT_DIR_FALLBACK := "user://exports"

var _export_dir := ""

# ── MP4 state ──
var _mp4_frames_dir := ""
var _mp4_fps        := 24
var _mp4_quality    := 23
signal mp4_export_done(path: String)
signal mp4_progress(current_frame: int, total_frames: int)

# =============================================
# Ready
# =============================================
func _ready() -> void:
	scene_manager  = get_node_or_null("/root/Main/SceneManager")
	object_manager = get_node_or_null("/root/Main/SceneObjects")
	camera_manager = get_node_or_null("/root/Main/CameraManager")
	anim_manager   = get_node_or_null("/root/Main/AnimationManager")
	scene_objects  = get_node_or_null("/root/Main/SceneObjects")
	_setup_export_dir()

func _setup_export_dir() -> void:
	var da := DirAccess.open("/storage/emulated/0/Download")
	if da != null:
		if not DirAccess.dir_exists_absolute(EXPORT_DIR_ANDROID):
			DirAccess.make_dir_absolute(EXPORT_DIR_ANDROID)
		_export_dir = EXPORT_DIR_ANDROID
	else:
		var user_path := ProjectSettings.globalize_path(EXPORT_DIR_FALLBACK)
		if not DirAccess.dir_exists_absolute(user_path):
			DirAccess.make_dir_absolute(user_path)
		_export_dir = user_path
	print("Export dir: ", _export_dir)

func _get_path(filename: String) -> String:
	return _export_dir + "/" + filename

# =============================================
# ① EXPORT PNG
# =============================================
func export_png() -> void:
	var cam := _get_active_camera()
	if cam == null:
		_show_toast("⚠ No camera found"); return

	var was_current := cam.current
	cam.current = true
	await RenderingServer.frame_post_draw

	var img  := get_viewport().get_texture().get_image()
	var name := "capture_%d.png" % Time.get_ticks_msec()
	var path := _get_path(name)
	img.save_png(path)
	cam.current = was_current

	_show_toast("✔ PNG saved:\n" + path)
	print("PNG: ", path)

func export_png_from_camera(cam_id: String) -> void:
	if camera_manager == null: return
	var cam: Camera3D
	if cam_id == "main":
		cam = get_node_or_null("/root/Main/CameraBase/Camera3D")
	else:
		var data = camera_manager._custom_cameras.get(cam_id, {})
		cam = data.get("camera", null)
	if cam == null: return

	var prev := _get_active_camera()
	cam.current = true
	await RenderingServer.frame_post_draw
	var img  := get_viewport().get_texture().get_image()
	var name := "cam_%s_%d.png" % [cam_id, Time.get_ticks_msec()]
	img.save_png(_get_path(name))
	if prev: prev.current = true
	_show_toast("✔ PNG: " + name)

# =============================================
# ② EXPORT GIF (ZIP of frames)
# =============================================
func export_gif(frames_count: int = 24, delay_ms: int = 80) -> void:
	if anim_manager == null or camera_manager == null:
		await _export_gif_static(frames_count)
		return

	_show_toast("🎞 Recording animation…")
	await get_tree().process_frame

	var cameras_to_capture: Array = []
	var main_cam: Camera3D = get_node_or_null("/root/Main/CameraBase/Camera3D")
	if main_cam: cameras_to_capture.append({"id": "main", "cam": main_cam})

	for cam_id in camera_manager._custom_cameras:
		var data = camera_manager._custom_cameras[cam_id]
		var cam: Camera3D = data.get("camera", null)
		if cam: cameras_to_capture.append({"id": cam_id, "cam": cam})

	if cameras_to_capture.is_empty():
		_show_toast("⚠ No cameras"); return

	camera_manager.hide_visuals_for_capture()
	var ts := Time.get_ticks_msec()

	for cam_entry in cameras_to_capture:
		var cam: Camera3D = cam_entry["cam"]
		var cid: String   = cam_entry["id"]
		cam.current = true

		var zip_path := _get_path("anim_%s_%d.zip" % [cid, ts])
		var za := ZIPPacker.new()
		if za.open(zip_path) != OK: continue

		for i in frames_count:
			var t = (float(i) / frames_count) * anim_manager.duration
			anim_manager.seek(t)
			await RenderingServer.frame_post_draw
			await get_tree().process_frame
			var img := get_viewport().get_texture().get_image()
			var frame_name := "frame_%03d.png" % i
			za.start_file(frame_name)
			za.write_file(img.save_png_to_buffer())
			za.close_file()

		za.close()
		_show_toast("✔ ZIP: anim_%s_%d.zip" % [cid, ts])

	camera_manager.show_visuals_after_capture()
	var active = camera_manager.get_active_camera()
	if active: active.current = true
	_show_toast("✔ Frames saved to:\n" + _export_dir)

func _export_gif_static(frames_count: int) -> void:
	_show_toast("🎞 Recording %d frames…" % frames_count)
	var cam := _get_active_camera()
	if cam == null: return

	var zip_path := _get_path("capture_%d.zip" % Time.get_ticks_msec())
	var za := ZIPPacker.new()
	if za.open(zip_path) != OK: return

	for i in frames_count:
		await RenderingServer.frame_post_draw
		await get_tree().process_frame
		var img := get_viewport().get_texture().get_image()
		za.start_file("frame_%03d.png" % i)
		za.write_file(img.save_png_to_buffer())
		za.close_file()

	za.close()
	_show_toast("✔ Frames ZIP:\n" + zip_path)

# =============================================
# ③ EXPORT GLB
# =============================================
func export_glb(selected_ids: Array = []) -> void:
	if scene_manager == null:
		_show_toast("⚠ Scene not ready"); return
	if object_manager == null:
		_show_toast("⚠ ObjectManager not ready"); return
	if scene_manager.objects.is_empty():
		_show_toast("⚠ No objects to export"); return

	var gltf  := GLTFDocument.new()
	var state := GLTFState.new()
	var root  := Node3D.new()
	root.name = "CheetahMesh"

	var added := 0
	for obj_data in scene_manager.objects:
		if not obj_data.get("visible", true): continue
		if obj_data.get("type", "") == "camera": continue
		if selected_ids.size() > 0 and obj_data["id"] not in selected_ids: continue
		var mi := _make_export_mesh(obj_data)
		if mi == null: continue
		root.add_child(mi)
		mi.owner = root
		added += 1

	if added == 0:
		root.queue_free()
		_show_toast("⚠ No exportable meshes"); return

	var err := gltf.append_from_scene(root, state, 0)
	root.queue_free()

	if err != OK:
		_show_toast("✘ GLB error: %d" % err); return

	var path := _get_path("model_%d.glb" % Time.get_ticks_msec())
	err = gltf.write_to_filesystem(state, path)
	if err != OK:
		_show_toast("✘ GLB write error: %d" % err); return

	_show_toast("✔ GLB saved:\n" + path)
	print("GLB: ", path)

# =============================================
# ③.b EXPORT MP4
# =============================================

# ── هل الـ plugin موجود؟ ──
func _has_mp4_plugin() -> bool:
	return Engine.has_singleton("Mp4Plugin")

# تصدير كل الكاميرات
func export_mp4_all_cameras(
	anim_indices: Array = [],
	fps: int = 24,
	quality: int = 23
) -> void:
	var cam_list: Array = []
	var main_cam: Camera3D = get_node_or_null("/root/Main/CameraBase/Camera3D")
	if main_cam:
		cam_list.append({"id": "main", "cam": main_cam, "name": "Main"})
	if camera_manager != null:
		for cam_id in camera_manager._custom_cameras:
			var data = camera_manager._custom_cameras[cam_id]
			var cam: Camera3D = data.get("camera", null)
			if cam:
				cam_list.append({
					"id":   cam_id,
					"cam":  cam,
					"name": data.get("name", cam_id),
				})
	if cam_list.is_empty():
		_show_toast("⚠ No cameras found"); return

	for entry in cam_list:
		await export_mp4_single(entry["id"], entry["cam"], entry["name"], anim_indices, fps, quality)

# تصدير كاميرا واحدة
func export_mp4_camera(
	cam_id: String,
	anim_indices: Array = [],
	fps: int = 24,
	quality: int = 23
) -> void:
	var cam: Camera3D
	var cam_name: String

	if cam_id == "main":
		cam = get_node_or_null("/root/Main/CameraBase/Camera3D")
		cam_name = "Main"
	elif camera_manager != null and camera_manager._custom_cameras.has(cam_id):
		var data = camera_manager._custom_cameras[cam_id]
		cam = data.get("camera", null)
		cam_name = data.get("name", cam_id)
	else:
		_show_toast("⚠ Camera not found: " + cam_id); return

	if cam == null:
		_show_toast("⚠ Camera node missing"); return

	await export_mp4_single(cam_id, cam, cam_name, anim_indices, fps, quality)

# الدالة الأساسية
func export_mp4_single(
	cam_id: String,
	cam: Camera3D,
	cam_name: String,
	anim_indices: Array,
	fps: int,
	quality: int
) -> void:
	if anim_manager == null or anim_manager.animations.is_empty():
		_show_toast("⚠ No animations"); return

	var indices: Array = anim_indices
	if indices.is_empty():
		for i in anim_manager.animations.size(): indices.append(i)

	_mp4_fps     = clamp(fps, 1, 60)
	_mp4_quality = clamp(quality, 0, 51)
	_mp4_frames_dir = OS.get_user_data_dir() + "/mp4_frames/"
	DirAccess.make_dir_absolute(_mp4_frames_dir)

	# ── اختيار الـ backend ──
	var use_plugin := _has_mp4_plugin()
	if not use_plugin:
		_show_toast("ℹ Mp4Plugin غير موجود — سيتم التصدير كـ ZIP\n(فعّل الـ plugin للـ MP4 الحقيقي)")

	if camera_manager != null:
		camera_manager.hide_visuals_for_capture()

	var prev_cam := _get_active_camera()
	cam.current = true

	var saved_idx  = anim_manager.current_anim_idx
	var saved_time = anim_manager.current_time
	anim_manager.stop()

	for anim_idx in indices:
		if anim_idx < 0 or anim_idx >= anim_manager.animations.size(): continue
		var anim_data: Dictionary = anim_manager.animations[anim_idx]
		var anim_name: String     = anim_data.get("name", "anim_%d" % anim_idx)
		var safe_name: String     = anim_name.replace(" ", "_").replace("/", "-")
		var kfs: Array            = anim_data.get("keyframes", [])

		if kfs.is_empty():
			_show_toast("⚠ '%s' has no keyframes — skipped" % anim_name)
			continue

		var duration: float   = anim_data.get("duration", 4.0)
		var total_frames: int = int(ceil(duration * _mp4_fps))
		var ts := Time.get_ticks_msec()

		_mp4_clear_frames()
		anim_manager.select_animation(anim_idx)

		_show_toast("🎬 [%s] Rendering '%s'…\n%d frames" % [cam_name, anim_name, total_frames])

		# ── تصوير الـ frames ──
		for i in total_frames:
			var t := float(i) / float(_mp4_fps)
			anim_manager.seek(t)
			await RenderingServer.frame_post_draw
			await get_tree().process_frame
			var img := get_viewport().get_texture().get_image()

			if use_plugin:
				# نحفظ JPG للـ plugin
				img.convert(Image.FORMAT_RGB8)
				img.save_jpg(_mp4_frames_dir + "frame_%05d.jpg" % i, 0.88)
			else:
				# نحفظ PNG للـ ZIP
				img.save_png(_mp4_frames_dir + "frame_%05d.png" % i)

			mp4_progress.emit(i + 1, total_frames)
			if i % 15 == 0:
				_show_toast("🎬 %s — Frame %d/%d" % [anim_name, i + 1, total_frames])

		# ── تحويل أو تجميع ──
		if use_plugin:
			await _convert_with_plugin(safe_name, cam_id, ts)
		else:
			await _pack_frames_to_zip(safe_name, cam_id, ts, total_frames)

	# ── رجّع الحالة ──
	if camera_manager != null:
		camera_manager.show_visuals_after_capture()
	if prev_cam: prev_cam.current = true

	if saved_idx >= 0 and saved_idx < anim_manager.animations.size():
		anim_manager.select_animation(saved_idx)
		anim_manager.seek(saved_time)
	else:
		anim_manager.select_static()


# ── تحويل بالـ Plugin (Mp4Plugin.aar) ──
func _convert_with_plugin(safe_name: String, cam_id: String, ts: int) -> void:
	var plugin = Engine.get_singleton("Mp4Plugin")
	var out_name := "%s_%s_%d.mp4" % [safe_name, cam_id, ts]
	var out_path := _get_path(out_name)
	var vp_size  := get_viewport().get_visible_rect().size

	_show_toast("⏳ Converting → MP4…")
	await get_tree().process_frame

	var result: String = plugin.convertFramesToMp4(
		_mp4_frames_dir,
		out_path,
		_mp4_fps,
		int(vp_size.x),
		int(vp_size.y),
		_mp4_quality
	)

	if result.begins_with("OK:"):
		_show_toast("✔ MP4: " + out_name)
		mp4_export_done.emit(out_path)
		_mp4_clear_frames()
	else:
		_show_toast("✘ MP4 failed:\n" + result.right(-6).left(100))


# ── Fallback: يجمع الـ frames في ZIP ──
func _pack_frames_to_zip(safe_name: String, cam_id: String, ts: int, total_frames: int) -> void:
	var zip_name := "%s_%s_%d.zip" % [safe_name, cam_id, ts]
	var zip_path := _get_path(zip_name)
	var za := ZIPPacker.new()
	if za.open(zip_path) != OK:
		_show_toast("✘ Cannot create ZIP"); return

	_show_toast("📦 Packing frames…")
	for i in total_frames:
		var frame_file := _mp4_frames_dir + "frame_%05d.png" % i
		if not FileAccess.file_exists(frame_file): continue
		var fa := FileAccess.open(frame_file, FileAccess.READ)
		if fa == null: continue
		var data := fa.get_buffer(fa.get_length())
		fa.close()
		za.start_file("frame_%05d.png" % i)
		za.write_file(data)
		za.close_file()

	za.close()
	_mp4_clear_frames()
	_show_toast("✔ ZIP saved:\n" + zip_name + "\n(فعّل Mp4Plugin للـ MP4 الحقيقي)")
	mp4_export_done.emit(zip_path)


func _mp4_clear_frames() -> void:
	var da := DirAccess.open(_mp4_frames_dir)
	if da == null: return
	da.list_dir_begin()
	var f := da.get_next()
	while f != "":
		if f.ends_with(".jpg") or f.ends_with(".png"): da.remove(f)
		f = da.get_next()
	da.list_dir_end()

# =============================================
# ③.c EXPORT GLB مع أنيميشنات
# =============================================
func export_glb_animated_multi(selected_ids: Array = [], anim_indices: Array = []) -> void:
	if anim_manager == null or anim_manager.animations.is_empty():
		_show_toast("⚠ No animations to export"); return
	if scene_manager == null or object_manager == null:
		_show_toast("⚠ Scene not ready"); return

	var indices: Array = anim_indices
	if indices.is_empty():
		for i in anim_manager.animations.size(): indices.append(i)

	var saved_idx   = anim_manager.current_anim_idx
	var saved_time  = anim_manager.current_time
	anim_manager.stop()

	var ts       := Time.get_ticks_msec()
	var exported := 0

	for anim_idx in indices:
		if anim_idx < 0 or anim_idx >= anim_manager.animations.size(): continue
		var anim_data: Dictionary = anim_manager.animations[anim_idx]
		var anim_name: String     = anim_data.get("name", "anim_%d" % anim_idx)
		var safe_name: String     = anim_name.replace(" ", "_").replace("/", "-")
		var kfs: Array            = anim_data.get("keyframes", [])

		if kfs.is_empty():
			_show_toast("⚠ '%s' has no keyframes — skipped" % anim_name)
			continue

		var duration: float = anim_data.get("duration", 4.0)
		var fps:      float = anim_data.get("fps",      30.0)
		var loop:     bool  = anim_data.get("loop",     true)

		var anim_player := AnimationPlayer.new()
		var root := Node3D.new()
		root.name = "CheetahMesh"
		root.add_child(anim_player)
		anim_player.owner = root

		var mesh_nodes: Dictionary = {}
		var track_map:  Dictionary = {}

		for obj_data in scene_manager.objects:
			if not obj_data.get("visible", true): continue
			if obj_data.get("type", "") == "camera": continue
			if selected_ids.size() > 0 and obj_data["id"] not in selected_ids: continue
			var mi := _make_export_mesh(obj_data)
			if mi == null: continue
			root.add_child(mi)
			mi.owner = root
			mesh_nodes[obj_data["id"]] = mi

		if mesh_nodes.is_empty():
			root.queue_free(); continue

		var anim_res := Animation.new()
		anim_res.length    = duration
		anim_res.loop_mode = Animation.LOOP_LINEAR if loop else Animation.LOOP_NONE

		for id in mesh_nodes:
			var pos_t := anim_res.add_track(Animation.TYPE_VALUE)
			anim_res.track_set_path(pos_t, NodePath("%s:position"         % mesh_nodes[id].name))
			var rot_t := anim_res.add_track(Animation.TYPE_VALUE)
			anim_res.track_set_path(rot_t, NodePath("%s:rotation_degrees" % mesh_nodes[id].name))
			var scl_t := anim_res.add_track(Animation.TYPE_VALUE)
			anim_res.track_set_path(scl_t, NodePath("%s:scale"            % mesh_nodes[id].name))
			track_map[id] = { "pos": pos_t, "rot": rot_t, "scl": scl_t }

		anim_manager.select_animation(anim_idx)
		for kf in kfs:
			var t: float = kf["time"]
			anim_manager.seek(t)
			await get_tree().process_frame
			for obj_data in scene_manager.objects:
				var id: String = obj_data.get("id", "")
				if not track_map.has(id): continue
				var tr = track_map[id]
				anim_res.track_insert_key(tr["pos"], t, obj_data.get("position", Vector3.ZERO))
				anim_res.track_insert_key(tr["rot"], t, obj_data.get("rotation", Vector3.ZERO))
				anim_res.track_insert_key(tr["scl"], t, obj_data.get("scale",    Vector3.ONE))

		var anim_lib := AnimationLibrary.new()
		anim_lib.add_animation(safe_name, anim_res)
		anim_player.add_animation_library("", anim_lib)

		var gltf  := GLTFDocument.new()
		var state := GLTFState.new()
		get_tree().root.add_child(root)
		await get_tree().process_frame
		var err := gltf.append_from_scene(root, state, 0)
		get_tree().root.remove_child(root)

		if err != OK:
			root.queue_free()
			_show_toast("✘ GLB error on '%s': %d" % [anim_name, err])
			continue

		var file_name := "%s_%d.glb" % [safe_name, ts]
		var path      := _get_path(file_name)
		err = gltf.write_to_filesystem(state, path)
		root.queue_free()

		if err != OK:
			_show_toast("✘ Write error on '%s': %d" % [anim_name, err])
			continue

		_show_toast("✔ GLB: %s" % file_name)
		exported += 1

	if saved_idx >= 0 and saved_idx < anim_manager.animations.size():
		anim_manager.select_animation(saved_idx)
		anim_manager.seek(saved_time)
	else:
		anim_manager.select_static()

	if exported > 0:
		_show_toast("✔ %d animation(s) exported to:\n%s" % [exported, _export_dir])

# =============================================
# ④ EXPORT GIF Multi
# =============================================
func export_gif_multi(anim_indices: Array = [], frames_count: int = 24, _delay_ms: int = 60) -> void:
	if anim_manager == null or anim_manager.animations.is_empty():
		_show_toast("⚠ No animations to export"); return

	var indices: Array = anim_indices
	if indices.is_empty():
		for i in anim_manager.animations.size(): indices.append(i)

	var saved_idx  = anim_manager.current_anim_idx
	var saved_time = anim_manager.current_time
	anim_manager.stop()

	var ts       := Time.get_ticks_msec()
	var exported := 0

	if camera_manager != null:
		camera_manager.hide_visuals_for_capture()

	var active_cam := _get_active_camera()

	for anim_idx in indices:
		if anim_idx < 0 or anim_idx >= anim_manager.animations.size(): continue
		var anim_data: Dictionary = anim_manager.animations[anim_idx]
		var anim_name: String     = anim_data.get("name", "anim_%d" % anim_idx)
		var safe_name: String     = anim_name.replace(" ", "_").replace("/", "-")
		var kfs: Array            = anim_data.get("keyframes", [])
		var duration: float       = anim_data.get("duration", 4.0)

		if kfs.is_empty():
			_show_toast("⚠ '%s' has no keyframes — skipped" % anim_name)
			continue

		var zip_path := _get_path("%s_%d.zip" % [safe_name, ts])
		var za := ZIPPacker.new()
		if za.open(zip_path) != OK:
			_show_toast("✘ Cannot create ZIP for '%s'" % anim_name)
			continue

		_show_toast("🎞 Recording '%s'…" % anim_name)
		anim_manager.select_animation(anim_idx)

		for i in frames_count:
			var t := (float(i) / frames_count) * duration
			anim_manager.seek(t)
			await RenderingServer.frame_post_draw
			await get_tree().process_frame
			var img := get_viewport().get_texture().get_image()
			za.start_file("frame_%03d.png" % i)
			za.write_file(img.save_png_to_buffer())
			za.close_file()

		za.close()
		_show_toast("✔ ZIP: %s_%d.zip" % [safe_name, ts])
		exported += 1

	if camera_manager != null:
		camera_manager.show_visuals_after_capture()
	if active_cam: active_cam.current = true

	if saved_idx >= 0 and saved_idx < anim_manager.animations.size():
		anim_manager.select_animation(saved_idx)
		anim_manager.seek(saved_time)
	else:
		anim_manager.select_static()

	if exported > 0:
		_show_toast("✔ %d ZIP(s) saved to:\n%s" % [exported, _export_dir])

# =============================================
# ⑤ EXPORT OBJ + MTL
# =============================================
func export_obj(selected_ids: Array = []) -> void:
	if scene_manager == null:
		_show_toast("⚠ Scene not ready"); return
	if object_manager == null:
		_show_toast("⚠ ObjectManager not ready"); return
	if scene_manager.objects.is_empty():
		_show_toast("⚠ No objects to export"); return

	var ts       := Time.get_ticks_msec()
	var obj_path := _get_path("model_%d.obj" % ts)
	var mtl_path := _get_path("model_%d.mtl" % ts)
	var mtl_name := "model_%d.mtl" % ts

	var obj_buf := PackedStringArray()
	var mtl_buf := PackedStringArray()
	obj_buf.append("# CheetahMesh OBJ Export")
	obj_buf.append("mtllib " + mtl_name)
	obj_buf.append("")

	var vertex_offset := 1

	for obj_data in scene_manager.objects:
		if not obj_data.get("visible", true): continue
		if obj_data.get("type", "") == "camera": continue
		if selected_ids.size() > 0 and obj_data["id"] not in selected_ids: continue

		var id: String = obj_data["id"]
		var src_mi = object_manager.get_node_by_id(id)
		if src_mi == null or src_mi.mesh == null: continue

		var mesh: ArrayMesh
		if src_mi.mesh is ArrayMesh:
			mesh = src_mi.mesh
		else:
			mesh = _prim_to_array_mesh(src_mi.mesh)
		if mesh.get_surface_count() == 0: continue

		var name_s: String = obj_data.get("name", id).replace(" ", "_")
		var pos:   Vector3 = obj_data.get("position", Vector3.ZERO)
		var rot:   Vector3 = obj_data.get("rotation", Vector3.ZERO)
		var scl:   Vector3 = obj_data.get("scale",    Vector3.ONE)
		var color: Color   = obj_data.get("color",    Color(0.8, 0.4, 0.15))

		var mat_name := "mat_" + name_s
		obj_buf.append("usemtl " + mat_name)
		obj_buf.append("o " + name_s)

		var _ks: float = obj_data.get("metalness", 0.0)
		var _ns: float = (1.0 - obj_data.get("roughness", 0.5)) * 900.0 + 10.0
		mtl_buf.append("newmtl " + mat_name)

		var tex_filename := ""
		if src_mi.has_meta("paint_img"):
			var paint_img: Image = src_mi.get_meta("paint_img")
			tex_filename = "tex_%s_%d.png" % [name_s, ts]
			paint_img.save_png(_get_path(tex_filename))
			mtl_buf.append("map_Kd " + tex_filename)
			mtl_buf.append("Kd 1.0 1.0 1.0")
		else:
			mtl_buf.append("Kd %.4f %.4f %.4f" % [color.r, color.g, color.b])

		mtl_buf.append("Ka 0.1 0.1 0.1")
		mtl_buf.append("Ks %.4f %.4f %.4f" % [_ks, _ks, _ks])
		mtl_buf.append("Ns %.1f" % [_ns])
		mtl_buf.append("")

		var xform := Transform3D()
		xform = xform.scaled(scl)
		xform = Transform3D(Basis.from_euler(rot * PI / 180.0), Vector3.ZERO) * xform
		xform.origin = pos

		for s in mesh.get_surface_count():
			var arrays := mesh.surface_get_arrays(s)
			if arrays == null: continue
			var verts:   PackedVector3Array = arrays[Mesh.ARRAY_VERTEX]
			var normals: PackedVector3Array = arrays[Mesh.ARRAY_NORMAL] if arrays[Mesh.ARRAY_NORMAL] else PackedVector3Array()
			var uvs:     PackedVector2Array = arrays[Mesh.ARRAY_TEX_UV] if arrays[Mesh.ARRAY_TEX_UV] else PackedVector2Array()
			var indices: PackedInt32Array   = arrays[Mesh.ARRAY_INDEX]  if arrays[Mesh.ARRAY_INDEX]  else PackedInt32Array()

			for i in verts.size():
				var v := xform * verts[i]
				obj_buf.append("v %.6f %.6f %.6f" % [v.x, v.y, -v.z])
			for i in normals.size():
				var n := xform.basis * normals[i]
				obj_buf.append("vn %.6f %.6f %.6f" % [n.x, n.y, -n.z])
			for i in uvs.size():
				obj_buf.append("vt %.6f %.6f" % [uvs[i].x, 1.0 - uvs[i].y])

			var n_verts := verts.size()
			var has_uv  := uvs.size() > 0
			var has_n   := normals.size() > 0

			if indices.is_empty():
				for i in range(0, n_verts, 3):
					var a := vertex_offset + i
					var b := vertex_offset + i + 1
					var c := vertex_offset + i + 2
					if has_uv and has_n:
						obj_buf.append("f %d/%d/%d %d/%d/%d %d/%d/%d" % [a,a,a, b,b,b, c,c,c])
					elif has_n:
						obj_buf.append("f %d//%d %d//%d %d//%d" % [a,a, b,b, c,c])
					else:
						obj_buf.append("f %d %d %d" % [a, b, c])
			else:
				for i in range(0, indices.size(), 3):
					var a := vertex_offset + indices[i]
					var b := vertex_offset + indices[i + 1]
					var c := vertex_offset + indices[i + 2]
					if has_uv and has_n:
						obj_buf.append("f %d/%d/%d %d/%d/%d %d/%d/%d" % [a,a,a, b,b,b, c,c,c])
					elif has_n:
						obj_buf.append("f %d//%d %d//%d %d//%d" % [a,a, b,b, c,c])
					else:
						obj_buf.append("f %d %d %d" % [a, b, c])

			vertex_offset += n_verts
		obj_buf.append("")

	var fa_obj := FileAccess.open(obj_path, FileAccess.WRITE)
	if fa_obj == null:
		_show_toast("✘ Cannot write OBJ"); return
	fa_obj.store_string("\n".join(obj_buf))
	fa_obj.close()

	var fa_mtl := FileAccess.open(mtl_path, FileAccess.WRITE)
	if fa_mtl:
		fa_mtl.store_string("\n".join(mtl_buf))
		fa_mtl.close()

	_show_toast("✔ OBJ saved:\n" + obj_path)
	print("OBJ: ", obj_path)

# =============================================
# ⑥ IMPORT
# =============================================
func import_model() -> void:
	pass

func _on_import_file_selected(path: String) -> void:
	if not FileAccess.file_exists(path):
		_show_toast("✘ File not found:\n" + path); return

	var ext := path.get_extension().to_lower()
	var supported := ["glb", "gltf", "obj", "dae"]

	if ext not in supported:
		_show_toast("✘ Unsupported format: ." + ext + "\nSupported: " + ", ".join(supported))
		return

	_show_toast("⏳ Importing " + path.get_file() + "…")
	await get_tree().process_frame
	await _import_via_gltf(path, ext)

func _import_via_gltf(path: String, ext: String) -> void:
	var gltf  := GLTFDocument.new()
	var state := GLTFState.new()
	var err: int

	match ext:
		"glb", "gltf", "obj", _:
			err = gltf.append_from_file(path, state)

	if err != OK:
		_show_toast("✘ Failed to read file (error %d)" % err)
		return

	var imported_root: Node3D = gltf.generate_scene(state) as Node3D
	if imported_root == null:
		_show_toast("✘ Failed to generate scene"); return

	get_tree().root.add_child(imported_root)
	await get_tree().process_frame

	var mesh_nodes := _collect_mesh_instances(imported_root)

	if mesh_nodes.is_empty():
		imported_root.queue_free()
		_show_toast("✘ No meshes found in file"); return

	var count := 0
	for mi in mesh_nodes:
		if mi.mesh == null: continue
		_spawn_from_mesh_instance(mi, path.get_basename().get_file())
		count += 1

	imported_root.queue_free()

	if count == 0:
		_show_toast("✘ No valid geometry found")
	else:
		_show_toast("✔ Imported %d mesh(es):\n%s" % [count, path.get_file()])

func _collect_mesh_instances(node: Node) -> Array:
	var result := []
	if node is MeshInstance3D and node.mesh != null:
		result.append(node)
	for child in node.get_children():
		result.append_array(_collect_mesh_instances(child))
	return result

func _spawn_from_mesh_instance(src_mi: MeshInstance3D, base_name: String) -> void:
	var src_mesh := src_mi.mesh
	var am := ArrayMesh.new()
	var has_original_uvs := false

	for s in src_mesh.get_surface_count():
		var arrays := src_mesh.surface_get_arrays(s)
		if arrays == null or arrays[Mesh.ARRAY_VERTEX] == null: continue
		if arrays[Mesh.ARRAY_VERTEX].size() == 0: continue
		if arrays[Mesh.ARRAY_COLOR] == null or arrays[Mesh.ARRAY_COLOR].size() == 0:
			var vc := PackedColorArray()
			vc.resize(arrays[Mesh.ARRAY_VERTEX].size())
			vc.fill(Color.WHITE)
			arrays[Mesh.ARRAY_COLOR] = vc
		if arrays[Mesh.ARRAY_TEX_UV] != null and arrays[Mesh.ARRAY_TEX_UV].size() > 0:
			has_original_uvs = true
		am.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)

	if am.get_surface_count() == 0: return

	var original_texture: Image = null
	var base_color := Color(0.8, 0.4, 0.15)
	var metalness  := 0.0
	var roughness  := 0.5

	var src_mat: StandardMaterial3D = null
	if src_mi.material_override is StandardMaterial3D:
		src_mat = src_mi.material_override as StandardMaterial3D
	elif src_mi.get_surface_override_material_count() > 0:
		var m = src_mi.get_surface_override_material(0)
		if m is StandardMaterial3D: src_mat = m as StandardMaterial3D
	if src_mat == null and src_mesh.get_surface_count() > 0:
		var sm = src_mesh.surface_get_material(0)
		if sm is StandardMaterial3D: src_mat = sm as StandardMaterial3D

	if src_mat != null:
		base_color = src_mat.albedo_color
		metalness  = src_mat.metallic
		roughness  = src_mat.roughness
		if src_mat.albedo_texture != null:
			original_texture = src_mat.albedo_texture.get_image()

	var obj_name = src_mi.name if src_mi.name != "" else base_name
	var id       := "imp_%d_%d" % [Time.get_ticks_msec(), randi() % 9999]

	var obj_entry := {
		"id":                 id,
		"name":               obj_name,
		"kind":               -1,
		"position":           scene_objects.to_local(src_mi.global_position),
		"rotation":           src_mi.rotation_degrees,
		"scale":              src_mi.scale,
		"visible":            true,
		"color":              base_color,
		"metalness":          metalness,
		"roughness":          roughness,
		"emissive":           Color.BLACK,
		"emissive_intensity": 0.0,
		"resolution":         0,
		"hollow":             0.0,
		"imported":           true,
		"mesh_ref":           am,
		"has_original_uvs":   has_original_uvs,
		"original_texture":   original_texture,
	}

	scene_manager.objects.append(obj_entry)
	scene_manager.selected_id = id
	scene_manager.object_added.emit(obj_entry)
	scene_manager.object_selected.emit(id)
	scene_manager.scene_changed.emit()

# =============================================
# Helpers
# =============================================
func _get_active_camera() -> Camera3D:
	if camera_manager != null:
		return camera_manager.get_active_camera()
	return get_node_or_null("/root/Main/CameraBase/Camera3D")

func _make_export_mesh(obj_data: Dictionary) -> MeshInstance3D:
	var id: String = obj_data["id"]
	if object_manager == null: return null
	var src_mi = object_manager.get_node_by_id(id)
	if src_mi == null or src_mi.mesh == null: return null

	var mi := MeshInstance3D.new()
	mi.name = obj_data.get("name", id)

	var src_mesh: ArrayMesh
	if src_mi.mesh is ArrayMesh:
		src_mesh = src_mi.mesh
	else:
		src_mesh = _prim_to_array_mesh(src_mi.mesh)
	mi.mesh = src_mesh

	var mat := StandardMaterial3D.new()
	mat.albedo_color               = Color.WHITE
	mat.vertex_color_use_as_albedo = false
	mat.metallic  = obj_data.get("metalness", 0.0)
	mat.roughness = obj_data.get("roughness",  0.5)

	if src_mi.has_meta("paint_img"):
		var img: Image = src_mi.get_meta("paint_img")
		mat.albedo_texture = ImageTexture.create_from_image(img)
	else:
		mat.albedo_color = obj_data.get("color", Color.WHITE)

	mi.material_override = mat
	mi.position         = obj_data.get("position", Vector3.ZERO)
	mi.rotation_degrees = obj_data.get("rotation", Vector3.ZERO)
	mi.scale            = obj_data.get("scale",    Vector3.ONE)
	return mi

func _prim_to_array_mesh(prim: Mesh) -> ArrayMesh:
	var am := ArrayMesh.new()
	if prim.get_surface_count() == 0: return am
	var arrays := prim.surface_get_arrays(0)
	if arrays == null: return am
	if arrays[Mesh.ARRAY_COLOR] == null or arrays[Mesh.ARRAY_COLOR].size() == 0:
		var vc := PackedColorArray()
		vc.resize(arrays[Mesh.ARRAY_VERTEX].size()); vc.fill(Color.WHITE)
		arrays[Mesh.ARRAY_COLOR] = vc
	am.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	return am

# =============================================
# Toast
# =============================================
func _show_toast(msg: String) -> void:
	var ui := get_node_or_null("/root/Main/UI")
	if ui == null: return
	var lbl := Label.new()
	lbl.text = msg
	lbl.autowrap_mode = TextServer.AUTOWRAP_WORD
	lbl.add_theme_color_override("font_color",
		Color(0.2, 1.0, 0.4) if msg.begins_with("✔") else
		Color(1.0, 0.4, 0.3) if msg.begins_with("✘") else
		Color(1.0, 0.9, 0.5))
	lbl.set_anchor(SIDE_LEFT, 0.1); lbl.set_anchor(SIDE_RIGHT, 0.9)
	lbl.set_anchor(SIDE_TOP,  1);   lbl.set_anchor(SIDE_BOTTOM, 1)
	lbl.set_offset(SIDE_TOP,   -100); lbl.set_offset(SIDE_BOTTOM, -48)
	lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	lbl.z_index = 200
	ui.add_child(lbl)
	await get_tree().create_timer(4.0).timeout
	lbl.queue_free()
